This is a modified version of the Demos\TZipSFX\SFXDemo2 
(C)2002-2004 Markus Stephany

Changes
  TZipSFX renamed TZipSFXPlus
 