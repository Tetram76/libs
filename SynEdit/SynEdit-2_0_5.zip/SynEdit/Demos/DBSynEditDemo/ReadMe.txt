DBEditDemo1.dpr
---------------

- Needs Delphi 2 or higher.
- Demonstrates the TDBSynEdit component.

