DelphiWebScript II 2.0
======================

Installation
------------
            
- Docs\dws2Basics.html



Documentation
-------------

- Docs\index.html



License
-------

Mozilla Public License (MPL) 1.1

Docs\dwsLicense.html
http://www.mozilla.org/MPL/



Authors
-------

Initiator: 
Ackermann, Matthias (Switzerland)

Contributors:
See Contributors.txt

For further information go to: http://www.dwscript.com