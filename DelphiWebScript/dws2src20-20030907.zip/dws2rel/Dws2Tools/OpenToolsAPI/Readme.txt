{ Created May 26, 2003 by Mark Ericksen }

This project is designed to provide a foundation for OpenToolsAPI development with helper
classes and functions. This is packaged in a runtime package so it can easily be used
by multiple design-time experts/editors.

