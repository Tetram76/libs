The demo makes use of the SynEdit editor. It is not require to make use of the DWS 
features being demonstrated. The use can be addapted to other editor types.

SynEdit can be found here (http://synedit.sourceforge.net)
