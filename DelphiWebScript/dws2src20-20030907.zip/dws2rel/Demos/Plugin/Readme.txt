

                  DWSII PlugIn Demo for Delphi 5 


-) Load PlugInDemo.bpg
-) Compile the Plg1 package
-) run plgMain
-) enjoy


