DelphiWebScript II - Simple Demoprogram
=======================================

The simplest case of usage for DWSII

Run SimpleDemo.dpr