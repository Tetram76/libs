DelphiWebScript II - Demoprogram
================================

This demo program shows all basic functionality of DWSII 1.1. 

If you don't have Delphi Professional you'll get the error message 
that a component was not found. Just ignore that message and go on.

Run DwsDemo.dpr