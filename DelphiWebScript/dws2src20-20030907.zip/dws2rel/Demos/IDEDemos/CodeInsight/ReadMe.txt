The demos were created to demonstrate the ease and power of Code Insight (Code Complete)
for Delphi Web Script symbols. In order to function correctly, they require SynEdit.

SynEdit is OpenSource (MPL) (http://synedit.sourceforge.net)

The SynEdit features being used for the demos require current SynEdit code 
(from CVS on "Fri Dec 20 13:07:33 2002 UTC" or later). Any later public releases should
be fine. At the time of this writing, the only way to get these new features was through
CVS.

-Mark Ericksen
1 Jan 2003