#!/bin/sh
#
# shell script to create templates

cp ../source/include/jcl.template.inc ../source/include/jclc5.inc
cp ../source/include/jcl.template.inc ../source/include/jclc6.inc
cp ../source/include/jcl.template.inc ../source/include/jclkc3.inc
cp ../source/include/jcl.template.inc ../source/include/jclkd3.inc
cp ../source/include/jcl.template.inc ../source/include/jcld5.inc
cp ../source/include/jcl.template.inc ../source/include/jcld6.inc
cp ../source/include/jcl.template.inc ../source/include/jcld7.inc
cp ../source/include/jcl.template.inc ../source/include/jclcs1.inc
cp ../source/include/jcl.template.inc ../source/include/jcld8.inc
cp ../source/include/jcl.template.inc ../source/include/jcld9.inc
cp ../source/include/jcl.template.inc ../source/include/jcld9.net.inc
cp ../source/include/jcl.template.inc ../source/include/jcld10.inc
cp ../source/include/jcl.template.inc ../source/include/jcld10.net.inc
cp ../source/include/jcl.template.inc ../source/include/jcld11.inc
cp ../source/include/jcl.template.inc ../source/include/jcld11.net.inc
cp ../source/include/jcl.template.inc ../source/include/jcld12.inc

