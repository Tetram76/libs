#!/bin/bash

rm -f `find -name \*~`
rm -f `find -name *.~*`
rm -f `find -name *.a`
rm -f `find -name *.bpi`
rm -f `find -name *.dcp`
rm -f `find -name *.dcu`
rm -f `find -name *.dpu`
rm -f `find -name *.hpp`
rm -f `find -name *.o`
rm -f packages/k?/*.mak